import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from policy import hard_status,greedy_augmented,decide,ask_policy

H={'age_min':18,'age_max':65,'who_to_meet':['man','woman','non_binary'],'relationship_structure':'monogamous','smoking':'no','partner_smoking':'any','has_children':False,'partner_children':'any','wants_children':'unsure','acceptable_zones':['zone_a'],'schedule':['weekend_day']}
def member(i,partial=False):
    f=H.copy()
    if partial:f={k:None for k in f}
    return {'member_id':i,'pool_id':'p','age':27,'gender':'woman','zone':'zone_a','available':True,'fields':f,'field_status':{k:'not_asked' if v is None else 'observed' for k,v in f.items()}}
class Checks(unittest.TestCase):
    def test_feasible(self):self.assertEqual('feasible',hard_status(member('A'),member('B')))
    def test_known_failure_priority(self):
        a=member('A');b=member('B',True);a['fields']['age_max']=20
        self.assertEqual('infeasible',hard_status(a,b))
    def test_missing_blocks(self):self.assertEqual('needs_clarification',hard_status(member('A'),member('B',True)))
    def test_augment(self):
        pairs=greedy_augmented([('A','B',.9),('A','C',.6),('B','D',.6)])
        self.assertEqual({('A','C'),('B','D')},set(pairs))
    def test_bundle_budget(self):
        s={'members':[member('A',True),member('B',True),member('C',True),member('D',True),member('E',True)],'ask_budget_remaining':12,'ask_log':[],'introductions':[]}
        a=ask_policy(s);self.assertLessEqual(3*len(a),12);self.assertEqual(len(a),len({r['member_id'] for r in a}))
    def test_declined_not_asked(self):
        a=member('A',True);a['field_status']['age_min']='declined';s={'members':[a,member('B')],'ask_budget_remaining':12,'ask_log':[]}
        self.assertFalse(any(q['member_id']=='A' for q in ask_policy(s)))
    def test_atomic_batch(self):
        s={'members':[member('A'),member('B'),member('C')],'introductions':[]}
        out=decide({'phase':'match','state':s});self.assertEqual(len(out['pairs']),1)
    def test_repeat_excluded(self):
        s={'members':[member('A'),member('B')],'introductions':[{'user_a':'A','user_b':'B'}]}
        self.assertEqual([],decide({'phase':'match','state':s})['pairs'])
    def test_empty(self):
        self.assertEqual([],decide({'phase':'ask','state':{'members':[],'ask_budget_remaining':12}})['asks'])
if __name__=='__main__':unittest.main()

class AdditionalChecks(unittest.TestCase):
    def test_two_to_two_swap(self):
        # Greedy initially takes A-B and C-D, but exchanging endpoints is superior.
        edges=[('A','B',0.9),('C','D',0.8),('A','C',0.87),('B','D',0.86)]
        chosen=greedy_augmented(edges)
        self.assertEqual({('A','C'),('B','D')},set(chosen))
    def test_reciprocal_zone(self):
        a=member('A');b=member('B');b['zone']='zone_b'
        b['fields']['acceptable_zones']=['zone_a','zone_b']
        self.assertEqual('infeasible',hard_status(a,b))
    def test_smoking_known_conflict_over_missing(self):
        a=member('A');b=member('B',True)
        a['fields']['partner_smoking']='no_smoking';b['fields']['smoking']='yes'
        self.assertEqual('infeasible',hard_status(a,b))
    def test_soft_ask_uses_residual_budget(self):
        a=member('A');b=member('B');a['fields']['relationship_goal']=None
        a['field_status']['relationship_goal']='not_asked'
        s={'members':[a,b],'ask_budget_remaining':1,'ask_log':[],'introductions':[]}
        self.assertEqual([],ask_policy(s))  # isolated edge: answer cannot change allocation
    def test_declined_soft_not_reasked(self):
        a=member('A');b=member('B');a['fields']['relationship_goal']=None
        a['field_status']['relationship_goal']='declined'
        s={'members':[a,b],'ask_budget_remaining':1,'ask_log':[],'introductions':[]}
        self.assertFalse(any(q['member_id']=='A' and q['field']=='relationship_goal' for q in ask_policy(s)))
    def test_hard_missing_prevents_match(self):
        s={'members':[member('A'),member('B',True)],'introductions':[]}
        self.assertEqual([],decide({'phase':'match','state':s})['pairs'])
