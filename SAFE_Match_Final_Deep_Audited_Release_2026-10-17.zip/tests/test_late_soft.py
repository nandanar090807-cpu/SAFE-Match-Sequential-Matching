"""Regression tests for the single validated late-stage clarification change."""
import unittest
from tests.test_policy import member
from policy import ask_policy

class LateClarificationChecks(unittest.TestCase):
    def test_soft_question_not_removed_on_day_39(self):
        a,b,c=member('A'),member('B'),member('C')
        a['fields']['relationship_goal']=None
        a['field_status']['relationship_goal']='not_asked'
        s={'members':[a,b,c],'day':39,'ask_budget_remaining':1,'ask_log':[],'introductions':[]}
        self.assertEqual([{'member_id':'A','field':'relationship_goal'}],ask_policy(s))

    def test_soft_question_removed_on_day_40(self):
        a,b,c=member('A'),member('B'),member('C')
        a['fields']['relationship_goal']=None
        a['field_status']['relationship_goal']='not_asked'
        s={'members':[a,b,c],'day':40,'ask_budget_remaining':1,'ask_log':[],'introductions':[]}
        self.assertEqual([],ask_policy(s))

    def test_late_constraints_still_asked(self):
        a,b=member('A',True),member('B',True)
        s={'members':[a,b],'day':59,'ask_budget_remaining':6,'ask_log':[],'introductions':[]}
        asked=ask_policy(s)
        self.assertEqual({('A','constraints'),('B','constraints')},{(x['member_id'],x['field']) for x in asked})
        self.assertEqual(6,sum(3 if x['field']=='constraints' else 1 for x in asked))

if __name__=='__main__':unittest.main()
