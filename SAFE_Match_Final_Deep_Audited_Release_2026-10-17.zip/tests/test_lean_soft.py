"""Regression tests added after measured clarification-only optimization."""
import unittest, importlib.util, sys
from pathlib import Path
from policy import ask_policy,decide
from kit import Simulator,generate
ROOT=Path(__file__).resolve().parents[1]
# Frozen source is shipped outside the participant container and is used only by tests.
BASE=ROOT/'baseline'/'policy.py'
spec=importlib.util.spec_from_file_location('frozen_original',BASE)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
ALLOWED={'constraints','relationship_goal','relationship_pace','lifestyle','conversations'}
class LeanSoftRegression(unittest.TestCase):
    def test_question_subset_matches_frozen_original(self):
        for variant in ('development','sparse','cold_start','delayed','shift','drift'):
            simulator=Simulator(generate(1257,200,'evaluation',variant))
            for _ in range(4):
                s=simulator.observe()
                expected=[q for q in original.ask_policy(s) if q['field'] in ALLOWED]
                self.assertEqual(expected,ask_policy(s))
                self.assertTrue(all(q['field'] in ALLOWED for q in ask_policy(s)))
                self.assertLessEqual(sum(3 if q['field']=='constraints' else 1 for q in ask_policy(s)),12)
                simulator.resolve_asks(ask_policy(s))
                pairs=decide({'phase':'match','state':simulator.observe(),'memory':None})['pairs']
                simulator.advance(pairs)
    def test_matching_decision_is_identical_on_observed_state(self):
        sim=Simulator(generate(1312,200,'evaluation','development'))
        for day in range(10):
            s=sim.observe()
            sim.resolve_asks(ask_policy(s))
            s=sim.observe()
            req={'phase':'match','state':s,'memory':{'v':False}}
            self.assertEqual(original.decide(req),decide(req))
            sim.advance(decide(req)['pairs'])
    def test_ignored_soft_fields_never_requested(self):
        sim=Simulator(generate(567,200,'evaluation','cold_start'))
        for _ in range(10):
            s=sim.observe()
            self.assertFalse(any(q['field'] in {'emotional_availability','space_for_relationship','relocate'} for q in ask_policy(s)))
            sim.resolve_asks(ask_policy(s))
            sim.advance(decide({'phase':'match','state':sim.observe()})['pairs'])
if __name__=='__main__':unittest.main()
