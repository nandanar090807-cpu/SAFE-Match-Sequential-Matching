"""Adversarial contract, matching, protocol and reproducibility tests.
Reference parity below is against the publicly documented test mirror, not the official evaluator.
"""
import copy
import itertools
import json
import random
import subprocess
import sys
import time
import unittest
from pathlib import Path
from policy import HARD, SOFT, ask_policy, allocate, decide, greedy_augmented, hard_status
from tests.test_policy import member

ROOT = Path(__file__).resolve().parents[1]

class ContractChecks(unittest.TestCase):
    def test_memory_identity(self):
        for payload in (None, [], {}, 0, False, '', [0], {'a': [1]}):
            req = {'phase': 'ask', 'memory': payload, 'state': {'members': [], 'ask_budget_remaining': 12}}
            self.assertEqual(payload, decide(req)['memory'])

    def test_missing_memory_defaults_null(self):
        self.assertIsNone(decide({'phase': 'match', 'state': {}})['memory'])

    def test_single_feasible_edge_does_not_prompt_soft_questions(self):
        a, b = member('A'), member('B')
        a['fields']['relationship_goal'] = None
        a['field_status']['relationship_goal'] = 'not_asked'
        self.assertEqual([], ask_policy({'members': [a, b], 'ask_budget_remaining': 12, 'introductions': [], 'ask_log': []}))

    def test_soft_field_useful_with_choices(self):
        a, b, c = member('A'), member('B'), member('C')
        a['fields']['relationship_goal'] = None
        a['field_status']['relationship_goal'] = 'not_asked'
        asks = ask_policy({'members': [a, b, c], 'ask_budget_remaining': 1, 'introductions': [], 'ask_log': []})
        self.assertEqual([{'member_id': 'A', 'field': 'relationship_goal'}], asks)

    def test_refused_partner_never_triggers_wasted_hard_ask(self):
        a, b = member('A', True), member('B', True)
        b['field_status']['age_min'] = 'declined'
        self.assertEqual([], ask_policy({'members': [a, b], 'ask_budget_remaining': 12, 'introductions': [], 'ask_log': []}))

    def test_old_question_never_reasked(self):
        a, b = member('A', True), member('B')
        asks = ask_policy({'members': [a, b], 'ask_budget_remaining': 12,
                           'introductions': [], 'ask_log': [{'member_id': 'A', 'field': 'constraints'}]})
        self.assertFalse(any(x['member_id'] == 'A' and x['field'] == 'constraints' for x in asks))

    def test_ask_budget_for_every_unit(self):
        people = [member(f'M{i}', partial=i < 8) for i in range(14)]
        for limit in range(13):
            state = {'members': people, 'ask_budget_remaining': limit, 'introductions': [], 'ask_log': []}
            asks = ask_policy(state)
            cost = sum(3 if a['field'] == 'constraints' else 1 for a in asks)
            self.assertLessEqual(cost, limit)
            self.assertEqual(len(asks), len({(a['member_id'], a['field']) for a in asks}))
            self.assertTrue(all(a['field'] in SOFT + ('constraints',) for a in asks))

    def test_no_unavailable_or_duplicate_matches(self):
        people = [member(f'M{i}') for i in range(14)]
        people[5]['available'] = False
        past = [{'user_a': 'M0', 'user_b': 'M1'}]
        pairs = allocate({'members': people, 'introductions': past})
        ids = [x for pair in pairs for x in pair]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertNotIn('M5', ids)
        self.assertNotIn(['M0', 'M1'], pairs)

    def test_exact_small_fallback_fuzz(self):
        try:
            import networkx as nx
        except ImportError:
            self.skipTest('networkx not locally installed')
        rng = random.Random(7712)
        for _ in range(250):
            n = rng.randint(2, 10)
            edges = [(str(i), str(j), round(rng.random() * 5, 5))
                     for i, j in itertools.combinations(range(n), 2) if rng.random() < .6]
            local = greedy_augmented(edges)
            weights = {tuple(sorted((a,b))): w for a,b,w in edges}
            got = sum(weights[p] for p in local)
            graph = nx.Graph()
            graph.add_weighted_edges_from(edges)
            optimal = sum(weights[tuple(sorted(x))] for x in nx.max_weight_matching(graph))
            self.assertAlmostEqual(got, optimal, places=7)

    def test_subprocess_valid_json_memory_preserved(self):
        for phase in ('ask', 'match'):
            req = {'schema_version': '1.0.0', 'phase': phase,
                   'state': {'members': [], 'ask_budget_remaining': 12, 'introductions': [], 'ask_log': []},
                   'memory': {'history': [1, 2]}}
            proc = subprocess.run([sys.executable, str(ROOT / 'policy.py')],
                                  input=json.dumps(req), text=True, capture_output=True, timeout=10)
            self.assertEqual(0, proc.returncode, proc.stderr)
            self.assertEqual('', proc.stderr)
            lines = proc.stdout.splitlines()
            self.assertEqual(1, len(lines))
            result = json.loads(lines[0])
            self.assertEqual({'history': [1, 2]}, result['memory'])
            self.assertEqual({'memory', 'asks' if phase == 'ask' else 'pairs'}, set(result))

    def test_boundary_day_budget_and_oversize_response(self):
        people = [member(f'M{i}') for i in range(200)]
        s = {'members': people, 'introductions': [], 'ask_budget_remaining': 12, 'ask_log': [], 'day': 59}
        t = time.monotonic()
        pairs = allocate(s)
        self.assertLess(time.monotonic() - t, 10)
        self.assertEqual(100, len(pairs))
        self.assertLess(len(json.dumps({'pairs': pairs, 'memory': None}).encode()), 1024*1024)

    def test_official_reference_parity_when_kit_is_present(self):
        try:
            from kit import eligibility, generate
        except ImportError:
            self.skipTest('Official kit.py is not installed beside the submission')
        for seed in (1001, 1002, 1003):
            mem = generate(seed, n=80)['members']
            for a, b in itertools.combinations(mem, 2):
                self.assertEqual(eligibility(a, b)['status'], hard_status(a, b))

if __name__ == '__main__':
    unittest.main()
