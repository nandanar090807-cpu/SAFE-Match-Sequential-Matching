"""Regressions for packaged Round 2 retest, not claims about private scoring."""
import json, subprocess, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class RemediationTests(unittest.TestCase):
    def invoke_raw(self, payload):
        proc=subprocess.run([sys.executable,str(ROOT/'policy.py')],
                            input=json.dumps(payload), capture_output=True,text=True,timeout=10)
        self.assertEqual(proc.returncode,0,proc.stderr)
        self.assertEqual(1,len(proc.stdout.splitlines()))
        return json.loads(proc.stdout),proc.stderr

    def test_fallback_preserves_valid_memory_after_bad_state(self):
        for phase in ('ask','match'):
            memory={'hello':{'nested':[None,False,0,[],{'x':'y'}]}}
            response,stderr=self.invoke_raw({'phase':phase,'state':{'members':[{'available':True}]},'memory':memory})
            self.assertEqual(response['memory'],memory)
            self.assertEqual(response['asks' if phase=='ask' else 'pairs'],[])
            self.assertIn('safe fallback',stderr)

    def test_fallback_nulls_nonfinite_memory_instead_of_crashing(self):
        payload={'phase':'ask','state':{'members':[{'available':True}]},'memory':float('nan')}
        response,_=self.invoke_raw(payload)
        self.assertIsNone(response['memory'])
        self.assertEqual([],response['asks'])

    def test_project_root_has_required_entrypoint(self):
        self.assertTrue((ROOT/'policy.py').is_file())
        self.assertTrue((ROOT/'Dockerfile').is_file())
        self.assertTrue((ROOT/'requirements.txt').is_file())
        self.assertTrue((ROOT/'README.md').is_file())
        self.assertTrue((ROOT/'REPORT.md').is_file())

    def test_dockerfile_copies_only_inference_sources(self):
        docker=(ROOT/'Dockerfile').read_text()
        self.assertIn('COPY policy.py ',docker)
        self.assertIn('COPY requirements.txt ',docker)
        self.assertNotIn('COPY . ',docker)

if __name__=='__main__':unittest.main()
