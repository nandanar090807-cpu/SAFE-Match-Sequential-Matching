"""Submission hardening checks for the exact vendored matcher and fallback."""
import json
import os
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest import mock

from policy import allocate
from kit import eligibility

ROOT=Path(__file__).resolve().parents[1]


def member(number):
    fields={
        'age_min':18, 'age_max':65,
        'who_to_meet':['woman','man','non_binary'],
        'relationship_structure':'monogamous','smoking':'no',
        'partner_smoking':'any','has_children':False,'partner_children':'any',
        'wants_children':'unsure', 'acceptable_zones':['zone_a'],
        'schedule':['weekday_evening'],
        'relationship_goal':'long_term', 'relationship_pace':'steady',
        'lifestyle':'quiet','conversations':'ideas',
        'emotional_availability':'ready','space_for_relationship':'moderate',
        'relocate':'unsure',
    }
    return {'member_id':f'syn_{number:032x}', 'pool_id':'pool', 'age':25,
            'gender':'woman','zone':'zone_a','available':True,
            'fields':fields,'field_status':{k:'observed' for k in fields}}


class ReleaseHardeningTests(unittest.TestCase):
    def test_unknown_solver_exception_degrades_to_legal_pairs(self):
        members=[member(i) for i in range(4)]
        state={'members':members,'introductions':[]}
        fake=types.ModuleType('networkx')
        class Graph:
            def add_weighted_edges_from(self,*args): pass
        fake.Graph=Graph
        def bad(*args,**kwargs):
            raise KeyError('unexpected internal solver graph failure')
        fake.algorithms=types.SimpleNamespace(matching=types.SimpleNamespace(max_weight_matching=bad))
        with mock.patch.dict(sys.modules,{'networkx':fake}):
            pairs=allocate(state)
        self.assertEqual(len(pairs),2)
        used=[i for p in pairs for i in p]
        self.assertEqual(len(used),len(set(used)))
        look={m['member_id']:m for m in members}
        for a,b in pairs:self.assertEqual(eligibility(look[a],look[b])['status'],'feasible')

    def test_vendor_is_present_with_redistribution_license(self):
        self.assertTrue((ROOT/'vendor/networkx/__init__.py').is_file())
        license_file=ROOT/'vendor/networkx-3.6.1.dist-info/licenses/LICENSE.txt'
        self.assertTrue(license_file.is_file())
        self.assertIn('3-clause BSD',license_file.read_text())
        self.assertIn('COPY vendor/', (ROOT/'Dockerfile').read_text())
        self.assertNotIn('pip install',(ROOT/'Dockerfile').read_text())

    def test_isolated_python_imports_vendor_and_matches(self):
        env=os.environ.copy()
        env['PYTHONPATH']=str(ROOT/'vendor')
        env['PYTHONDONTWRITEBYTECODE']='1'
        request={'schema_version':'1.0.0','phase':'match',
                 'state':{'schema_version':'1.0.0','synthetic':True,'day':0,
                          'ask_budget_remaining':12,'members':[member(i) for i in range(4)],
                          'introductions':[],'feedback':[],'ask_log':[]},
                 'memory':{'carry':'unchanged'}}
        run=subprocess.run([sys.executable,'-S',str(ROOT/'policy.py')],
                           input=json.dumps(request),text=True,capture_output=True,
                           env=env,timeout=9)
        self.assertEqual(run.returncode,0,run.stderr)
        response=json.loads(run.stdout)
        self.assertEqual(response['memory'],request['memory'])
        self.assertEqual(len(response['pairs']),2)
        check=subprocess.run([sys.executable,'-S','-c',
                              'import networkx; print(networkx.__version__,networkx.__file__)'],
                             env=env,text=True,capture_output=True,timeout=9)
        self.assertEqual(check.returncode,0,check.stderr)
        self.assertIn('3.6.1',check.stdout)
        self.assertIn('vendor/networkx',check.stdout.replace('\\','/'))


if __name__=='__main__':unittest.main()
