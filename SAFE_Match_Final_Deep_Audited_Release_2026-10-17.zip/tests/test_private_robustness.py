"""Release robustness tests using only legal public contract data.
Private assessment worlds are not available; these are randomized proxy checks.
"""
import itertools, json, random, unittest, importlib.util
from pathlib import Path
from kit import Simulator, generate, eligibility
from policy import hard_status, ask_policy, allocate, greedy_augmented, edge_score, decide
ROOT = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit_original', ROOT/'audit_baseline/policy.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)

class PrivateProxyTests(unittest.TestCase):
    def test_known_incompatibility_dominates_missing(self):
        members=Simulator(generate(809, 2)).observe()['members']
        a,b=members
        a['fields']['who_to_meet']=['non_binary' if b['gender']!='non_binary' else 'woman']
        a['fields']['age_min']=None
        self.assertEqual('infeasible',hard_status(a,b))

    def test_eligibility_randomized_reference_equivalence(self):
        checks=0
        for seed in range(44,56):
            for variant in ('development','sparse','cold_start','delayed','shift','drift'):
                ms=Simulator(generate(seed,40,'p',variant)).observe()['members']
                for a,b in itertools.combinations(ms,2):
                    self.assertEqual(eligibility(a,b)['status'],hard_status(a,b))
                    self.assertEqual(old.hard_status(a,b),hard_status(a,b))
                    checks+=1
        self.assertGreater(checks,27000)

    def test_ask_batch_budget_refusals_and_duplicates(self):
        for seed in range(101,151):
            variant=('development','sparse','cold_start','delayed','shift','drift')[seed%6]
            sim=Simulator(generate(seed,200,'p',variant))
            state=sim.observe();state['ask_budget_remaining']=seed%13
            requests=ask_policy(state)
            self.assertEqual(len(requests),len({(a['member_id'],a['field']) for a in requests}))
            self.assertLessEqual(sum(3 if a['field']=='constraints' else 1 for a in requests),seed%13)
            self.assertTrue(all(a['member_id'] in {m['member_id'] for m in state['members'] if m['available']} for a in requests))
            for a in requests:
                person=next(m for m in state['members'] if m['member_id']==a['member_id'])
                if a['field']=='constraints':
                    self.assertFalse(any(person['field_status'][k]=='declined' for k in old.HARD))
                else: self.assertNotEqual(person['field_status'][a['field']],'declined')

    def test_randomized_action_equivalence_on_public_states(self):
        # Compare all actions before applying them: no behavioral change is allowed from the micro-optimization.
        for seed in range(101,111):
            sim=Simulator(generate(seed,200,'p',('development','sparse','cold_start')[seed%3]))
            for day in range(3):
                for phase in ('ask','match'):
                    req={'schema_version':'1.0.0','phase':phase,'state':sim.observe(),'memory':{'day':day}}
                    before=old.decide(req)
                    after=decide(req)
                    self.assertEqual(before,after)
                    if phase=='ask':sim.resolve_asks(after['asks'])
                    else:sim.advance(after['pairs'])

    def test_random_matching_bruteforce_small(self):
        rng=random.Random(991133)
        def brute(edges,n):
            choices=[(a,b,w) for a,b,w in edges]
            def go(start,used,total):
                if start==len(choices):return total
                a,b,w=choices[start];best=go(start+1,used,total)
                if a not in used and b not in used:best=max(best,go(start+1,used|{a,b},total+w))
                return best
            return go(0,set(),0.0)
        for _ in range(80):
            n=rng.randint(2,7);vs=[str(i) for i in range(n)]
            edges=[(a,b,round(rng.uniform(.01,3),2)) for a,b in itertools.combinations(vs,2) if rng.random()<.48]
            result=greedy_augmented(edges)
            weights={(a,b):w for a,b,w in edges}
            actual=sum(weights[tuple(sorted(x))] for x in result)
            expect=brute(edges,n)
            self.assertAlmostEqual(expect,actual,places=8)
            self.assertEqual(len(set(x for pair in result for x in pair)),2*len(result))

    def test_memory_preserved_and_empty_state(self):
        state={'day':0,'ask_budget_remaining':12,'members':[],'introductions':[],'feedback':[],'ask_log':[]}
        for memory in (None,True,0,'abc',[],{'blob':'z'*900000}):
            for phase in ('ask','match'):
                o=decide({'schema_version':'1.0.0','phase':phase,'state':state,'memory':memory})
                self.assertEqual(o['memory'],memory)
                self.assertEqual(o['asks' if phase=='ask' else 'pairs'],[])
                self.assertLess(len(json.dumps(o,allow_nan=False)),1024*1024)

if __name__=='__main__':unittest.main()
