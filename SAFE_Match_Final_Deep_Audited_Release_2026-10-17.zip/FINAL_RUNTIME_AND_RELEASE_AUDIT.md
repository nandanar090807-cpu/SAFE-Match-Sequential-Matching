# SAFE-Match Round 2 — final runtime and release audit

**17 October 2026 | Code review and real execution evidence | Nandan A R**

## Decision

**CONDITIONALLY READY / not Docker-certified.** Code and exact public-simulator tests pass; assessed Docker execution was not possible in the current tool runtime. The package includes a GitHub Actions workflow to run that remaining mandatory gate after the user pushes the project into their own repository. Do not claim a final Docker PASS, full private-case compliance, a private score, or competition submission.

## What was actually repaired

1. **Network installation risk in Docker build:** formerly `RUN pip install --no-cache-dir -r requirements.txt` installed NetworkX 3.4.2, a version different from the 3.6.1 actually tested locally. Now the image copies the tested, exact BSD-licensed pure-Python NetworkX **3.6.1** into `/app/vendor`, sets `PYTHONPATH`, and launches `python -S` to avoid unexpected site dependencies. No `pip` or `apt` occurs during image build. The **Python base image must still be pulled** from Docker Hub; its tag is not digest-pinned. Actual Docker image build is still unverified.
2. **Solver exception resilience:** `policy.allocate` previously caught only ImportError, RuntimeError and ValueError during exact matching; an unexpected graph-solver exception would reach the outer empty-batch fallback and drop all feasible introductions. It now falls back to the deterministic legality-checked matcher for any ordinary Exception from the solver. A fault-injection test raises KeyError and verifies legal disjoint pairs. This preserves ordinary exact-solver results.
3. **Bytecode portability:** bundling the library initially brought along Python 3.13 `__pycache__` files. These have been removed. `VENDOR_SHA256.json` verifies **296** immutable source/metadata/license files and ignores regenerated `.pyc` cache files.
4. **Executable Docker validation elsewhere:** `.github/workflows/docker-validation.yml` runs unit tests, builds the real Docker image, runs the organizer's exact public Docker evaluator, and uploads the result JSON. It has **not** run yet; it runs only after the project is pushed and GitHub Actions is enabled.
5. **Release documentation and provenance:** the README, pinned requirement declaration, dependency-license metadata, test integrity manifest, and `preflight.py` reflect the actual bundled version and explicitly expose the Docker blockage.

The main matching weights, question selection, hard eligibility semantics, and normal-path matching behavior were otherwise preserved.

## Real commands and observed results

| Check | Outcome | Raw evidence |
|---|---|---|
| `PYTHONPATH=vendor python -S -m unittest -q` | **46 of 46 PASS** | `results/hardening_tests.log`; stdout rerun |
| `python -S verify_vendor.py` | **PASS** (296 files) | Vendor checksum verifier + manifest |
| `PYTHONPATH=vendor python -S stress_process.py` | **7 of 7 PASS** | `results/release_stress.log` |
| Six heterogeneous complete 200-member graphs, fresh `python -S` matcher | **6 of 6 PASS**, 100 nonoverlapping pairs each, 1.22–1.46 s | `results/vendor_dense_stress.json` |
| Unprivileged 2-CPU, 1 GiB, 9-second-limited 200-member input | **PASS**, 1.24 s, 38,724 KiB max child RSS (system `time`) | `results/restricted_runtime.txt`, `results/restricted_dense_response.json` |
| Organizer's **unmodified** `evaluate.py` + `kit.py`, full seed-711 episode, `PYTHONPATH=vendor python -S` | **PASS**, 120 separate policy subprocesses | `results/final_offline_evaluator_711.json`, `.log`, `.exit` |
| Fresh episode MSMI, introductions, clarification units | **1**, **102**, **267** | Official public evaluator JSON |
| Frozen old/new action SHA-256 | **MATCH**, `8a464cd6204b7b7c5bea9953dcb38c88876a42785320e1edd7fd7dd09c6c69ce` | Compare `results/verified_evaluator_711.json` with newest result |
| Source hash parity with organizer public reference | **PASS** | `results/release_preflight.json` |
| Strict `python preflight.py --require-docker` | **Exit 2 / Docker BLOCKED**, all non-Docker checks PASS | `results/release_preflight.log`, `.json` |
| A longer three-seed differential batch | **INCOMPLETE** (overall execution timeout; partial episode logs only) | `results/release_replay.log`; do not count as pass |
| Exact assessed Docker image and hidden private cases | **NOT RUN** | Docker socket/executable unavailable; private cases inaccessible |

Official evaluator event count and scores are stochastic synthetic observations tied to the published generator; results are not estimates of real dating performance. No change in those scores can guarantee a private leaderboard outcome.

## Unresolved risks and required next actions

- **MANDATORY:** after uploading this exact project to the contestant's own GitHub repository, open **Actions → SAFE-Match Docker and Public Evaluator → Run workflow**, require green completion and inspect `results/docker_101.json`. Or run locally with Docker: `docker build --pull -t safe-match:submission .` then `python evaluate.py --image safe-match:submission --seeds 101 --variants development --output results/docker_101.json`, followed by `python preflight.py --require-docker`.
- If the Docker runner reports a failure, inspect the logs and repair; **do not submit a known failing image**. This generated workflow only enables the test; it is not proof of success.
- The Python 3.11 slim base tag is not pinned to a digest. A digest pin can be made from an actual verified Docker image after first successful build.
- The organizer public dataset verifier requires the full public dataset and checksums in the organizer's repository; it cannot run from this trimmed contestant ZIP alone.
- The rights notice in `LICENSE` is conservatively **all rights reserved** for contestant-owned work; the contestant should review before publication. The organizer kit retains MIT and NetworkX retains BSD-3-Clause terms. No external publishing or registration occurred in this run.
- The newest organizer announcement supersedes the old repo date: **17 October 2026, 23:59 IST**. Source must be pinned and the **Final submission** GitHub issue filed before that deadline.
- Hidden private evaluation remains unknown; performance on sparse geography may be limited, even if all introduction actions are valid.

## Reliable immediate commands

```bash
python -S verify_vendor.py
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=vendor python -S -m unittest -v
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=vendor python -S stress_process.py
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=vendor python -S evaluate.py --policy policy.py --seeds 711 --variants development --output results/recheck_711.json
python preflight.py --require-docker
```

All data files in the results directory reflect actual tests or clearly identified earlier experiments. `VENDOR_SHA256.json` protects the checked-in library source, and `LATEST_POLICY_DIFF.patch` shows the minimal policy code change.
