# SAFE-Match: independently executed pre-submission audit

**Date:** 17 October 2026 (before submission). **Status:** CONDITIONALLY READY FOR RELEASE PREPARATION; **NOT DOCKER-CERTIFIED OR SUBMITTED**.

## Source of truth and unchanged inference code

Original audited file: `SAFE_Match_Round2_Retested_Fixed_2026-10-16.zip` (42 entries, passed full `ZipFile.testzip()`). The original inference policy was preserved **byte-for-byte**. Its SHA-256 remains:

`a0b772f99070c17170648d04852828aa3648d0115932e21a8f2e66cd68097b9a`

Public reference files were compared to the official GitHub Git blob SHA values, not merely to local copies:

| Official source | Git blob SHA-1 | Result |
|---|---|---|
| `kit.py` | `b0356b84211debdb8fc1c3ea81348a034dd2ddbd` | Exact match |
| `evaluate.py` | `f9fa2617a3ef84da85502ec2bd730185d5049f65` | Exact match |
| `baseline/official_reference_policy.py` | `39766a8ea8c1d5090093e1a93c556f9d47ef8b29` | Exact match |

## Commands actually executed in this audit

| Check | Actual execution result | Raw evidence |
|---|---|---|
| ZIP CRC/integrity | PASS (42 entries) | Original verified by Python `zipfile` |
| `python -m unittest -v` | PASS, 37 tests | `audit/tests_before.log` |
| `python stress_process.py` | PASS, 7/7 adversarial checks | `audit/stress_process.log`, `results/adversarial_results_reproduced.json` |
| Recomputed official-reference parity | PASS, 62,573 comparisons, zero mismatches | `results/adversarial_results_reproduced.json` |
| Dense 200 members / 19,900 edges | PASS, 100 nonoverlapping pairs, ~2.29 s locally | `results/adversarial_results_reproduced.json` |
| 900 KB carried memory | PASS | `results/adversarial_results_reproduced.json` |
| `python evaluate.py --policy policy.py --seeds 711 --variants development` | PASS, valid full 60-day + 40-day episode, 120 fresh processes | `results/audit_official_711.json`, `audit/official_eval_711.log` |
| Public paired comparison `python reproduce_public.py --seeds 101,102,103 --variants all` | PASS, 72/72 valid | `results/audit_public_101_103.json`, `audit/public_eval.log` |
| Historical versus new action digests for those 72 episodes | PASS, 72/72 identical, zero mismatches | Verified against `results/public_101_103_with_diagnostics.json` |
| `python preflight.py` | PASS on local checks; Docker BLOCKED | `results/preflight_2026-10-17.json` |
| `python preflight.py --require-docker` | Correctly exits 2 (not certified) | `results/preflight_strict_2026-10-17.json` |
| Actual Docker build / official Docker evaluator | **BLOCKED; not executed** | Docker binary not installed |
| Exact pinned NetworkX 3.4.2 under Python 3.11 | **BLOCKED; not executed** | Local Python 3.13.5 + NetworkX 3.6.1; package index unavailable |
| Original organizer `python verify_data.py` | **BLOCKED in trimmed ZIP** | Public data and verifier excluded from policy source release |
| Immutable public URL and actual submission receipt | **NOT DONE** | Must be completed by user/authorized workflow |

The official fresh-process seed-711 result was: **valid=true, 1 qualifying MSMI, 102 assigned introductions, 267 clarification units**, action SHA-256:

`8a464cd6204b7b7c5bea9953dcb38c88876a42785320e1edd7fd7dd09c6c69ce`

This matched the historical recorded full-episode action hash. The subprocess runner reported **96.49 seconds total inference wall time over 120 individual calls**; this is NOT a per-call maximum or a Docker benchmark. The dense independent process test completed in ~2.29 s locally, below the 10-second target, but Docker must still be tested.

### Re-executed public scenario comparison (not private leaderboard)

| Policy | Valid episodes | Qualifying MSMI | Family-balanced MSMI/100 | Clarification units |
|---|---:|---:|---:|---:|
| SAFE-Match | 18/18 | 19 | 0.528 | 4,478 |
| Organizer greedy | 18/18 | 14 | 0.389 | 3,720 |
| Organizer random | 18/18 | 10 | 0.278 | 3,720 |
| Organizer no-asks | 18/18 | 5 | 0.139 | 0 |

These 18 episodes per policy use **only 3 independent seeds** across six related scenario families; they are weak evidence of private-score advantage. SAFE-Match has **0 MSMI events on the sparse-geography scenario for all three tested seeds**. The project is not claimed to be statistically guaranteed to beat greedy, let alone win the competition.

## Defects / changes handled in the release

1. **Missing seed/provenance declarations in README (fixed):** added explicit `training seeds: none` (fixed handwritten heuristic, no fitted ML model) and `inference random seed: not applicable` (deterministic policy). Listed public experiment seeds separately.
2. **No reproducible go/no-go single command (fixed):** added `preflight.py` that checks file layout, Git-blob parity, unit tests, fresh-process JSON/memory, then attempts actual Docker validation when available. `--require-docker` exits nonzero if Docker was not tested. Never substitutes a fake container test.
3. **Official public data verifier absent from trimmed ZIP (documented, not misrepresented as fixed):** the standalone competition source archive does not contain the full public data release. The original organizer verifier must be run from the cloned organizer data release; this is not a policy inference fault.
4. **Inference algorithm:** no confirmed new behavioral bug found in these tested states; **`policy.py` was not modified** to avoid an unvalidated last-minute regression.
5. **Pinned environment:** current Dockerfile pins NetworkX 3.4.2 on `python:3.11-slim`. This configuration remains untested here and is **a release blocker** until an actual image build and isolated official evaluator run succeed.
6. **Immutable submission:** a sandbox download URL is not equivalent to the organizer's required publicly accessible source artifact. Publish and pin a full Git commit SHA or a version-specific archive + exact SHA-256; file the Final submission issue with source, report, and results URLs.

## Release steps — do not skip

```bash
python -m unittest -v
python stress_process.py
python preflight.py --require-docker  # MUST EXIT 0 on a Docker-enabled machine
# Equivalent explicit container check:
docker build -t safe-match:submission .
python evaluate.py --image safe-match:submission --seeds 101 --variants development --output results/container_101.json
```

The newest organizer announcement provided by the participant sets the effective deadline at **17 October 2026 at 23:59 IST**, superseding the older GitHub guide's 18 October date. Final submission must use the organizer's **Final submission issue** and pin the assessed source immutably by the effective deadline.

**Bottom line:** The uploaded source is genuinely executable on the public simulator and passed this audit's checks. Docker execution, exact pinned dependency, organizer data-verification command and immutable public submission are outstanding. **Do not mark READY until they are completed.**
