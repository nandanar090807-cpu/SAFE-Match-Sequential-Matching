"""Public trusted in-process full-episode evaluation. Not a substitute for Docker.
Uses organizer kit/evaluate with no modification. No hidden state passed to policy.
"""
import argparse,importlib.util,sys,json,hashlib,collections,statistics,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
from kit import Simulator,generate
from evaluate import VARIANTS,validate_response,summarise

def load(path,name):
 spec=importlib.util.spec_from_file_location(name,str(path))
 mod=importlib.util.module_from_spec(spec)
 spec.loader.exec_module(mod)
 return mod
candidate=load(ROOT/'policy.py','candidate_policy')
official=load(ROOT/'baseline/official_reference_policy.py','organiser_policy')
def episode(seed,variant,method):
 sim=Simulator(generate(seed,200,'evaluation',variant));memory=None;h=hashlib.sha256();start=time.perf_counter()
 for _ in range(60):
  for phase in ('ask','match'):
   req={'schema_version':'1.0.0','phase':phase,'state':sim.observe(),'memory':memory}
   ans=(candidate.decide(req) if method=='SAFE-Match' else official.decide(req,method))
   ans=validate_response(ans,phase)
   action=ans['asks' if phase=='ask' else 'pairs']
   h.update(json.dumps([phase,sim.day,action],sort_keys=True).encode());memory=ans['memory']
   if phase=='ask':sim.resolve_asks(action)
   else:sim.advance(action)
 arrived={m['member_id']:m['arrived_day'] for m in sim.observe()['members'] if m['arrived_day']<=59}
 for _ in range(40):sim.advance([])
 result=sim.metrics()
 first={}
 for intro in sim.introductions:
  for mid in (intro['user_a'],intro['user_b']):first.setdefault(mid,intro['assigned_day'])
 waits=sorted(first[mid]-arrived[mid] for mid in first)
 result.update(seed=seed,variant=variant,policy=method,valid=True, action_sha256=h.hexdigest(),
               episode_wall_seconds=round(time.perf_counter()-start,4),
               arrived_members=len(arrived),served_members=len(first),
               unserved_members=len(arrived)-len(first),coverage=len(first)/max(1,len(arrived)),
               first_introduction_wait_days=waits,
               mean_first_introduction_wait_days=statistics.mean(waits) if waits else None)
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--seeds',default='101,102,103');p.add_argument('--variants',default='all');p.add_argument('--output',default='results/public_101_103.json');o=p.parse_args()
 seeds=[int(x) for x in o.seeds.split(',')];variants=VARIANTS if o.variants=='all' else o.variants.split(',')
 rows=[];out=Path(o.output);out.parent.mkdir(parents=True,exist_ok=True)
 for variant in variants:
  for seed in seeds:
   for method in ('SAFE-Match','greedy','no_asks','random'):
    try:r=episode(seed,variant,method)
    except Exception as e:r={'seed':seed,'variant':variant,'policy':method,'valid':False,'error':repr(e)}
    rows.append(r)
    out.write_text(json.dumps({'mode':'exact_kit_inprocess','episodes':rows},indent=2)+'\n')
    print(variant,seed,method,r['valid'],r.get('mutual_second_meeting_intention'),r.get('ask_cost'),flush=True)
 summary={}
 for method in ('SAFE-Match','greedy','no_asks','random'):
  cur=[r for r in rows if r['policy']==method];fs={}
  for variant in variants:
   v=[r['msmi_per_100_arrived_members'] for r in cur if r['variant']==variant and r['valid']]
   fs[variant]=statistics.mean(v) if v else None
  valid=all(r['valid'] for r in cur)
  summary[method]={'eligible':valid,'primary_score':statistics.mean(fs.values()) if valid else None,
                   'events':sum(r.get('mutual_second_meeting_intention',0) for r in cur),
                   'ask_cost':sum(r.get('ask_cost',0) for r in cur),'episodes':len(cur), 'family_msmi_per_100':fs}
 out.write_text(json.dumps({'mode':'exact_kit_inprocess','episodes':rows,'summary':summary},indent=2)+'\n')
 print('SUMMARY',json.dumps(summary,sort_keys=True),flush=True)
if __name__=='__main__':main()
