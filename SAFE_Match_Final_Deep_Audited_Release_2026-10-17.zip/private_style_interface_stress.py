"""Black-box fresh-process contract stress. It does NOT run private tests or Docker.
Applies 1GiB virtual-address and 2-CPU affinity limits when OS supports them.
"""
import json, random, os, sys, time, subprocess, resource, statistics, traceback
from pathlib import Path
from kit import Simulator, generate
from evaluate import strict_json, validate_response
ROOT=Path(__file__).resolve().parent
VARIANTS=('development','sparse','cold_start','delayed','shift','drift')

def limit():
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
    resource.setrlimit(resource.RLIMIT_CPU,(9,10))
    if hasattr(os,'sched_setaffinity'):
        allowed=sorted(os.sched_getaffinity(0))
        if len(allowed)>2:os.sched_setaffinity(0,set(allowed[:2]))

def call(state,phase):
    request={'schema_version':'1.0.0','phase':phase,'state':state,'memory':{'round_trip':'not_to_be_dropped'}}
    payload=json.dumps(request,allow_nan=False).encode()
    assert len(payload)<=1024*1024
    t=time.perf_counter()
    proc=subprocess.run([sys.executable,str(ROOT/'policy.py')],input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=limit,timeout=10)
    seconds=time.perf_counter()-t
    assert proc.returncode==0,(proc.returncode,proc.stderr[:300])
    assert len(proc.stdout)<=1024*1024 and len(proc.stderr)<=1024*1024
    response=validate_response(strict_json(proc.stdout.decode()),phase)
    assert response['memory']==request['memory']
    return response,seconds,len(payload),len(proc.stdout)

def main():
    rows=[];t=time.perf_counter()
    for k in range(18):
        variant=VARIANTS[k%6]
        sim=Simulator(generate(51000+k,200,'private_style',variant))
        for phase in ('ask','match'):
            state=sim.observe()
            result,wall,reqsize,outsize=call(state,phase)
            if phase=='ask':
                acts=result['asks']; sim.resolve_asks(acts)
            else:
                acts=result['pairs'];sim.advance(acts)
            rows.append({'sample':k,'variant':variant,'phase':phase,'valid':True,'wall_seconds':round(wall,4),
                         'request_bytes':reqsize,'response_bytes':outsize,'actions':len(acts)})
        if k%6==5:print('completed requests',len(rows),'elapsed',round(time.perf_counter()-t,2),flush=True)
    report={'test_type':'fresh subprocess restricted proxy; NOT docker/private','calls':len(rows),'valid_calls':len(rows),
            'max_call_wall_seconds':max(r['wall_seconds'] for r in rows),'median_call_wall_seconds':statistics.median(r['wall_seconds'] for r in rows),
            'peak_child_maxrss_kb':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'rows':rows}
    (ROOT/'results/private_style_interface_stress.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS',report['valid_calls'],'/',report['calls'],'worst',report['max_call_wall_seconds'],'maxrss',report['peak_child_maxrss_kb'],flush=True)
if __name__=='__main__':main()
