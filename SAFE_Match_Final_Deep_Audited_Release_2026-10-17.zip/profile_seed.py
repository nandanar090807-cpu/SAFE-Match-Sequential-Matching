import time,sys,json
from kit import Simulator,generate
from policy import decide
s=Simulator(generate(int(sys.argv[1]),200,'evaluation',sys.argv[2]));memory=None
for day in range(60):
 t=time.perf_counter(); obs=s.observe();t1=time.perf_counter()
 ans=decide({'phase':'ask','state':obs,'memory':memory});s.resolve_asks(ans['asks']);t2=time.perf_counter()
 obs=s.observe();ans=decide({'phase':'match','state':obs,'memory':memory});t3=time.perf_counter()
 s.advance(ans['pairs']);t4=time.perf_counter()
 print(day,'obs_s',round(t1-t,3),'ask_s',round(t2-t1,3),'match_s',round(t3-t2,3),'advance_s',round(t4-t3,3),'total_s',round(t4-t,3), 'intro',len(s.introductions),'events',len(s.events),flush=True)
