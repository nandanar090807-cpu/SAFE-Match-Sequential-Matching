"""Cross-version action equivalence on actual public kit; no private worlds used.
Run: python private_proxy_replay.py --seeds 1201,1202,1203
"""
import sys,json,time,hashlib,importlib.util,argparse,statistics,traceback
from pathlib import Path
from kit import Simulator,generate
from evaluate import VARIANTS, validate_response
ROOT=Path(__file__).resolve().parent

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,str(path));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def run(seed,variant,old,new):
    sim=Simulator(generate(seed,200,'evaluation',variant))
    memory=None; h=hashlib.sha256(); calls=0; errors=[]; timing=[]
    for day in range(60):
        for phase in ('ask','match'):
            req={'schema_version':'1.0.0','phase':phase,'state':sim.observe(),'memory':memory}
            start=time.perf_counter();a=validate_response(new.decide(req),phase);timing.append(time.perf_counter()-start)
            b=validate_response(old.decide(req),phase)
            if a!=b:
                errors.append({'day':day,'phase':phase,'old':b,'new':a})
                raise AssertionError('Action divergence '+str(errors[-1])[:1000])
            action=a['asks' if phase=='ask' else 'pairs'];h.update(json.dumps([phase,day,action],sort_keys=True).encode());calls+=1
            memory=a['memory']
            if phase=='ask': sim.resolve_asks(action)
            else:sim.advance(action)
    for _ in range(40):sim.advance([])
    m=sim.metrics()
    return {'seed':seed,'variant':variant,'valid':True,'calls':calls,'hash':h.hexdigest(),
            'msmi':m['mutual_second_meeting_intention'],'ask_cost':m['ask_cost'],
            'assignments':m['assignments'],'max_policy_seconds_inprocess':max(timing),
            'mean_policy_seconds_inprocess':statistics.mean(timing)}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seeds',default='1201,1202,1203');p.add_argument('--output',default='results/private_proxy_replay.json');args=p.parse_args()
 old=load(ROOT/'audit_baseline/policy.py','baseline_policy');new=load(ROOT/'policy.py','fixed_policy')
 rows=[]
 for seed in map(int,args.seeds.split(',')):
  for variant in VARIANTS:
   t=time.perf_counter()
   try: row=run(seed,variant,old,new)
   except Exception as ex: row={'seed':seed,'variant':variant,'valid':False,'error':repr(ex),'traceback':traceback.format_exc()}
   rows.append(row)
   Path(args.output).write_text(json.dumps({'source':'exact_public_kit_1.0.0','episodes':rows},indent=2)+'\n')
   print(seed,variant,row['valid'],row.get('msmi'), 'elapsed',round(time.perf_counter()-t,2),flush=True)
   if not row['valid']:raise SystemExit(1)
 print('valid',sum(x['valid'] for x in rows),'/',len(rows),'msmi_total',sum(x['msmi'] for x in rows))
