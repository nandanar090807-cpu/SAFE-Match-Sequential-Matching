# Development and tool provenance

- **Contestant:** Nandan A R.
- **AI-assisted development:** OpenAI ChatGPT assisted with code development, testing plans, error analysis, documentation and packaging during preparation of this submission. The contestant should verify this statement before publishing.
- **Inference policy:** No language model, remote service, trained predictive model, network access or undisclosed private dataset is used at inference time. The heuristic matching source is `policy.py`.
- **Organizer reference:** `kit.py`, `evaluate.py` and `baseline/official_reference_policy.py` are redistributed organizer MIT-licensed reference sources, confirmed against released Git blob hashes during the final audit.
- **Matching dependency:** BSD-3-Clause licensed NetworkX 3.6.1, source included under `vendor/`; `VENDOR_SHA256.json` verifies exact files.
- **Synthetic data:** Public organizer generator supplies fictional, seeded episodes. Public datasets are not shipped in the Docker image. None of the observed public scores imply access to the organizer's hidden/private worlds.
- **Execution verification:** Tests and commands reported as completed were actually executed. Docker was unavailable for the final audit; the GitHub Actions workflow is included but must be run separately.
