"""Verify the redistributed dependency exactly matches VENDOR_SHA256.json."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def verify():
    manifest=json.loads((ROOT/'VENDOR_SHA256.json').read_text())
    assert manifest['dependency']=='networkx' and manifest['version']=='3.6.1'
    expected=manifest['file_sha256']
    actual={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (ROOT/'vendor').rglob('*') if p.is_file()
            and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    assert actual==expected, 'Missing, extra, or altered vendored dependency files'
    print('Vendor checksum verification PASS: '+str(len(actual))+' files, NetworkX 3.6.1')
if __name__=='__main__':
    try:verify()
    except Exception as e:print('Vendor verification FAIL: '+str(e),file=sys.stderr);sys.exit(1)
