# SAFE-Match — independent final pre-submission audit

**Date:** 17 October 2026. **Verdict: CONDITIONALLY READY, not yet Docker-certified.**

## Source identified and frozen

- Exact incoming archive SHA-256: `9292faa959d2ef6ef32d3654d022fe81b1d8daacc3a4cca7a53950a1bde68b5c`.
- Reviewed `policy.py` SHA-256: `3ea3b0f6e054b99067beee4ebe44f45e21cad4bae45b215aec6879d4117e7707`. **No executable matching-policy modifications were made in this audit.**
- Reviewed `Dockerfile` SHA-256: `c464b127e31acb1fd2001152883614f489ebe6d5380b3b3ab62a24dea6bb064d`.
- The checked-in organizer `kit.py` and `evaluate.py` Git hashes agree with the current public repository.
- The original ZIP passed entry integrity checks (398 entries), with no directory-traversal paths or symlink entries. Vendored source plus metadata passes checksum verification (296 files).

## Freshly executed checks (this audit, not copied from old reports)

| Test | Observed result | Evidence |
|---|---|---|
| `python -m unittest -v` | **46/46 PASS** | `audit_evidence/unittest.stderr` |
| `PYTHONPATH=vendor python -S -m unittest -v` | **46/46 PASS** | `audit_evidence/isolated_unit.stderr` |
| `python verify_vendor.py` | 296/296 source and metadata files PASS | `verify_vendor.py`, `VENDOR_SHA256.json` |
| `PYTHONPATH=vendor python -S stress_process.py` | **7/7 PASS**, including dense 200-member graph | `audit_evidence/new_adversarial.log` |
| Restricted fresh-process interface | **36/36 PASS**; worst wall 0.968 s; peak observed child RSS ~108 MB | `audit_evidence/private_style_rerun.log` |
| Exactly 1 MiB valid request in each phase | **2/2 PASS**, memory preserved, output under 1 MiB | `audit_evidence/boundary_audit.json` |
| Differential reciprocal eligibility, six scenario families × four seeds | **235,797 pair comparisons, 0 mismatches** vs `kit.eligibility` | `audit_evidence/boundary_audit.json` |
| 20 legal decision days across six public scenario families | **649 accepted ask/match actions; no invalid action** | `audit_evidence/boundary_audit.json` |
| Organizer's unmodified `evaluate.episode()` with real fresh-process `invoke()` | **120/120 calls; VALID; 0 MSMI events, 201 ask units on seed 1207**; max individual call 0.1983 s using `python -S` | `audit_evidence/instrumented_1207.json` |
| `python preflight.py --require-docker` | Exit **2**; 10 local checks PASS, Docker BLOCKED | `audit_evidence/strict_preflight.json` |

The seed-1207 episode's zero MSMI events demonstrate that legality and ranking performance are different. A separate CLI evaluation with normal site-packages enabled had significant repeated interpreter-startup overhead and could not complete within the external overall execution timeout. The instrumentation run used the organizer's **unchanged `evaluate.episode()`, `evaluate.invoke()`, and `kit.py`** with the actual `python -S policy.py` process used by the submission's Docker entrypoint. No simulation or outcome code was altered; a wrapper logged invocation durations only. This is a local process run, not Docker and not hidden assessment.

An additional new in-process matched-seed 1301 benchmark was **INCOMPLETE** (11 episodes completed and valid before its overall command timeout). No score was claimed for the incomplete full suite. Archived earlier three-seed baseline comparisons remain historical evidence only.

## Submission-critical audit and corrections

1. **Policy correctness:** reciprocal eligibility, nonoverlap, repeated-pair prevention, clarification budget, JSON shapes, memory roundtrip and fallback checks passed in the tested corpus. This does not prove all private cases.
2. **Dependency reproducibility:** NetworkX 3.6.1 is bundled, hash checked, BSD-licensed and importable with Python `-S`. The original older report still referenced obsolete NetworkX 3.4.2 checks. This audit updated the report and test ledger to mark earlier results historical and to state the actual current dependency.
3. **Tool provenance:** added `AI_TOOL_PROVENANCE.md` to make code-assistance provenance and inference restrictions explicit. Please review the disclosure before publishing.
4. **Security/packaging:** root-level `policy.py` and Dockerfile present; image copies only the inference policy and vendor sources; no dataset, personal record or organizer world is mounted into the image by the Dockerfile. The base-image tag is not pinned to a digest, so exact base image reproducibility depends on Docker Hub.
5. **OPEN BLOCKER — Docker:** no Docker executable here. An actual `docker build` and `python evaluate.py --image ...` have **not** run. Running `preflight.py --require-docker` must return 0 on a Docker-enabled runner before calling the image certified.
6. **OPEN UNKNOWN — private performance:** private test seeds/worlds are inaccessible. Some public seeds underperform greedy or record no MSMI successes, including sparse geography. First place/top-15 ranking cannot be guaranteed.

## Mandatory launch checklist

On GitHub Actions or a Linux machine with Docker:

```bash
python -S verify_vendor.py
PYTHONPATH=vendor python -S -m unittest -v
docker build --pull -t safe-match:submission .
python evaluate.py --image safe-match:submission --seeds 101 --variants development --output results/docker_101.json
python preflight.py --require-docker
```

Require a successful Docker build and **valid** full episode JSON. The default GitHub Actions workflow is included, but no run has occurred on the user's GitHub repository. Pin the final GitHub source as a public full commit SHA or publish an immutable archive URL with its exact SHA-256. Submit through the organizer's Final Submission issue form by **17 October 2026 23:59 IST** (newer organizer message, overriding the older README in their public repo). Save the confirmation.

**Final judgement:** No newly confirmed policy correctness bug warrants last-minute algorithm changes. The documentation defects have been fixed. Docker remains the sole unverified mandatory runtime gate and private success cannot be guaranteed.
