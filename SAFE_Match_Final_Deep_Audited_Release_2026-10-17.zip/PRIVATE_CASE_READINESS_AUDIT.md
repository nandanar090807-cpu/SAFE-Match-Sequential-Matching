# SAFE-Match: private-case readiness hardening and final audit

**17 October 2026 · Nandan A R · public specification 1.0.0**

## Verdict: CONDITIONALLY READY for local release testing; NOT verified for assessed Docker execution

**No team can inspect or guarantee success on private evaluation cases.** This audit aims to preserve legality and deterministic behavior on varied *unseen public-generator seeds*, with no use of hidden information. The algorithm's private-score superiority is unknown. The final required Docker image evaluation has not run because Docker is unavailable in this environment; submit only after completing it elsewhere.

## Actually executed in this run

| Gate | Observed result | Evidence |
| --- | --- | --- |
| ZIP extraction/integrity | PASS (original 54 entries) | Original zip verified on extraction |
| Unit and regression suite | **43/43 PASS** (37 existing + 6 new) | `results/final_unit_tests.log` (exported from execution) |
| Public-reference eligibility comparison | PASS over **28,046** comparisons in randomized unit test | `tests/test_private_robustness.py` |
| Prior adversarial suite | **7/7 PASS**, including a 19,900-edge dense 200-person instance | `results/adversarial_results_reproduced.json` |
| Additional true public-simulator full episodes | **18/18 valid** on seeds 1201,1202,1203 across six variants | `results/private_proxy_18_episode_verified.json` |
| Frozen old-vs-new complete policy decisions | **2,160 phase decisions compared, 0 divergences** | Same JSON; both policies receive exactly the same observed state |
| Qualifying MSMI events in these new episodes | 17 combined | Descriptive only; not private-leaderboard evidence |
| Restricted subprocess trial | **36/36 valid**, 2-CPU affinity and 1-GiB address-space limits (where supported) | `results/private_style_interface_stress.json` |
| Worst observed restricted invocation | **0.9458 s** | Subprocess test, not Docker |
| Peak reported child-process max RSS | **108,068 KiB** | Linux resource usage, approximate |
| Pair-feasibility microbenchmark | median ~**1.66x faster** | `results/eligibility_timing.json` |
| Pinned dependency installed in target image | BLOCKED | Container build not performed; local NetworkX is 3.6.1 vs Docker-pinned 3.4.2 |
| Docker build + official isolated evaluator | BLOCKED | Docker executable not available |
| Organizer data `verify_data.py` | BLOCKED in trimmed submission archive | Released data directory/checksum files are not included here |
| New complete official subprocess *episode* after this micro-change | NOT VERIFIED | An attempted run exceeded the host batch time limit without an evaluator JSON. Previous version had such a run; new behavior was compared on complete in-process episodes. |
| Private held-back evaluation | UNAVAILABLE | No private data accessed |

## Change retained: early infeasibility rejection only

`policy.hard_status` now returns `infeasible` as soon as a known hard conflict is encountered instead of collecting all conflicts into a list. It preserves the reference semantics (a known conflict beats any missing field). No ask, edge-score, matching or scheduling strategy was changed. It is deliberately **not** a claimed improvement to MSMI.

Full diff: `PRIVATE_HARDENING_DIFF.patch`; unchanged previous source: `audit_baseline/policy.py`. The baseline replay script, `private_proxy_replay.py`, is portable inside this release.

## Issues discovered and corrected in this audit

1. **Preventable matching/clarification CPU work**: fixed with the early-return hard-gate, with cross-version semantic and action equivalence checks.
2. **New test harness defect**: an initial assertion expected more eligibility comparisons than the generated sample could provide. Corrected expected minimum to 27,000; reran all 43 tests successfully. This was a test harness error, not a policy failure.
3. **New replay script's archive-relative path**: corrected to load the archived baseline under `audit_baseline/` instead of a parent work directory. Reran six full episodes successfully after correction.

## Real blockers and risks

- The organizer's assessment executes the Dockerfile under read-only filesystem, offline networking, 2 cores, 1 GiB RAM and 10 s per invocation. A subprocess resource check does **not** certify those conditions.
- The score is sparse and seed-sensitive. On these 18 new public-generated episodes the algorithm recorded 17 qualifying events, including only one in sparse geography. Passing interface tests is separate from winning.
- The method's fixed edge weights and question heuristic are not calibrated second-meeting probabilities. Selecting the configuration against public synthetic seeds may overfit them; hidden outcome drift can reverse apparent gains.
- `NetworkX==3.4.2` is pinned by `requirements.txt` but was not installed in a verified Docker image. The dependency-free fallback preserves legal behavior, not optimality.
- The organizer's newer announcement gives **17 October 2026, 23:59 IST**. Publish an immutable source version and file the official Final Submission issue **before** the deadline. This file is not a submission confirmation.

## Reproduce from extracted ZIP root

```bash
python -m pip install -r requirements.txt
python -m unittest -v
python stress_process.py
python private_proxy_replay.py --seeds 1201 --output results/replayed_1201.json
python private_style_interface_stress.py
python preflight.py --require-docker
```

The final command must pass (exit 0) on a Docker-enabled host. Additionally run the unmodified organizer's container evaluator:

```bash
docker build -t safe-match:submission .
python evaluate.py --image safe-match:submission --seeds 101 --variants development --output results/container_check.json
```

**If the Docker gate fails, fix that failure and rerun all code and container tests before the deadline. Do not submit an archive with unverified dependencies without accepting the risk.**

The published `verify_data.py` requires the external released public data, manifest and checksums. Fetch/generate and verify those files from the original repository separately; they were intentionally excluded from the policy image.
