# SAFE-Match | Round 2 submission candidate

**Participant:** Nandan A R (individual)  
**Competition:** IIT Madras × Romeo & Juliet — The Sequential Matching Problem  
**Status:** Code and public-simulator checks passed; **actual Docker execution is still pending**. The authoritative latest audit is `FINAL_INDEPENDENT_AUDIT_2026-10-17.md`. Older `results/` files may document previous versions and must not be interpreted as current-build manifests.

## Architecture

The root `policy.py` is a fresh-process JSON adapter (one input JSON object, one output JSON object per process) following `docs/POLICY_INTERFACE.md` in the organizer's public repository. In the `ask` phase, it selects legal cost-bounded hard-bundle and selectively useful soft questions. In the `match` phase, it applies reciprocal hard constraints, then uses NetworkX's exact maximum-weight **general graph** matching, with a deterministic legality-preserving fallback. All scores are heuristic, **not calibrated probabilities of MSMI**. No unobserved answers, future arrivals, or simulator internals are consulted by inference.

The current release makes two robust changes relative to the prior hardened ZIP: (1) the exact solver has a general-exception fallback to prevent losing all feasible introductions if a solver or dependency raises unexpectedly; (2) the inference image bundles NetworkX 3.6.1, which was already the locally tested version, so no PyPI access is required during the build. It uses `python -S` to prevent accidental reliance on global site-packages. Ordinary decisions have been checked against the previous build on the public evaluator.

## Local tests (no Docker or PyPI needed)

Run from the project root with Python 3.11 or newer:

```bash
python -S verify_vendor.py
PYTHONPATH=vendor python -S -m unittest -v
PYTHONPATH=vendor python -S stress_process.py
PYTHONPATH=vendor python -S evaluate.py --policy policy.py --seeds 711 --variants development --output results/eval_711.json
python preflight.py --require-docker
```

Windows PowerShell: set `$env:PYTHONPATH = 'vendor'` before running the Python commands, or install the pinned dependency from `requirements.txt` instead.

`python preflight.py --require-docker` **must exit zero** for a certified Docker pass. In this work environment it exits 2 with `docker_build_and_evaluator=BLOCKED` because Docker cannot run here; its other checks pass. A successful non-Docker test cannot be substituted for this check.

## Docker build and benchmark

```bash
docker build --pull -t safe-match:submission .
python evaluate.py --image safe-match:submission --seeds 101 --variants development --output results/docker_101.json
python preflight.py --require-docker
```

The Dockerfile copies only the policy and the bundled library into `/app`; it installs **no packages during the image build**, and uses an unprivileged user. The base image `python:3.11-slim` still requires a first-time image pull from Docker Hub. The executable has to pass the organizer's network-disabled, read-only, two-CPU, 1 GiB, 10-second-per-call Docker evaluator. The base-image tag is not pinned to an OCI digest and should be pinned if reproducibility policy requires one.

### Docker without your local machine

Once this project is pushed to a GitHub repository, open the **Actions** tab and run **SAFE-Match Docker and Public Evaluator** manually (or let the push trigger it). `.github/workflows/docker-validation.yml` builds the actual Docker image and runs the organizer's public evaluator on GitHub's Ubuntu runner. Inspect the workflow's exit code and download its attached evaluator JSON; its presence in this ZIP does **not** mean the workflow has run.

## Results and limitations

- The bundled `kit.py`, `evaluate.py`, and reference policy match public organizer Git hashes checked by `preflight.py`.
- The executed fresh-process public evaluator seed 711 (development) returned valid, one qualifying MSMI event, 267 clarification units, and the same action hash as the earlier version: `8a464cd6204b7b7c5bea9953dcb38c88876a42785320e1edd7fd7dd09c6c69ce`.
- The full unit suite and adversarial suite pass in the self-contained vendor environment. Additional dense randomized 200-member matching stress cases are recorded under `results/vendor_dense_stress.json`.
- Historical public-simulator comparison results and earlier stress evidence are preserved in `results/` and `REPORT.md`; those are not hidden evaluation results.
- No supervised learning is deployed. **Training seeds: none. Inference randomness: none.** Experimental seed numbers are specified in the respective result files. The generator itself is stochastic in synthetic, seeded, reproducible ways.
- Private cases are inaccessible. Sparse-geography outcomes have been weak in some public sets; legitimate action compliance and competitive MSMI are separate questions.
- The public dataset verifier requires the data files from the organizer's original repository; these are not included in the inference image or this compact release. Run it in a complete organizer checkout.

## Licensing and submission

`policy.py` is the contestant's submitted source. `LICENSE` retains the author's asserted rights; review before publishing. See `AI_TOOL_PROVENANCE.md` for AI-assisted development disclosure and testing limitations. The bundled NetworkX 3.6.1 files are under **BSD 3-Clause** and include the license text in `vendor/networkx-3.6.1.dist-info/licenses/LICENSE.txt`. Organizer sources are under the attached `ORGANIZER_MIT_LICENSE.txt`, subject to the organizer's additional public-data conditions.

Open the organizer's **Final submission issue form** with a public immutable source URL, full 40-character commit SHA (or immutable archive URL + its exact SHA-256), report URL and machine-readable results. No submission or GitHub publishing was performed here. **Follow the newer organizer announcement: 17 October 2026, 23:59 IST.**

See `FINAL_RUNTIME_AND_RELEASE_AUDIT.md`, `REPORT.md`, `PRIVATE_CASE_READINESS_AUDIT.md`, and `results/` for additional details, including unverified gates.
