"""Actual stress invocations of the public evaluator subprocess adapter.
Reports only observed outcomes; 10s per-invocation hard limit.
"""
from __future__ import annotations
import json,sys,copy,random,time,subprocess,itertools,traceback,collections
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from kit import Simulator,generate,eligibility,HARD,SOFT
from evaluate import invoke,validate_response
from policy import decide,hard_status,greedy_augmented
CMD=[sys.executable,str(R/'policy.py')]
LOG=[]
def check(name,fn):
 t=time.perf_counter()
 try:
  info=fn()
  if not isinstance(info,dict):info={'details':str(info)}
  entry={'name':name,'status':'PASS','elapsed_s':round(time.perf_counter()-t,3),**info}
 except Exception as ex:
  entry={'name':name,'status':'FAIL','elapsed_s':round(time.perf_counter()-t,3),
         'exception':repr(ex),'traceback':traceback.format_exc()[-3000:]}
 LOG.append(entry);print(name,entry['status'],entry.get('elapsed_s'),entry.get('exception',''),flush=True)
 (R/'results/adversarial_results_reproduced.json').write_text(json.dumps(LOG,indent=2))

def request(state,phase='match',memory=None):return {'schema_version':'1.0.0','phase':phase,'state':state,'memory':memory}

def all_compatible_state(n=200,seed=4):
 rng=random.Random(seed)
 fs={'age_min':18,'age_max':65,'who_to_meet':['woman','man','non_binary'],
  'relationship_structure':'monogamous','smoking':'no','partner_smoking':'any',
  'has_children':False,'partner_children':'any','wants_children':'unsure',
  'acceptable_zones':['zone_a'],'schedule':['weekday_evening','weekend_day','weekend_evening'],
  'relationship_goal':'long_term','relationship_pace':'steady','lifestyle':'mixed',
  'conversations':'ideas','emotional_availability':'ready','space_for_relationship':'moderate','relocate':'unsure'}
 mem=[]
 for i in range(n):
  f=copy.deepcopy(fs)
  for k,choices in [('relationship_goal',['long_term','exploring']),('relationship_pace',['slow','steady','quick']),
                    ('lifestyle',['quiet','mixed','social']),('conversations',['ideas','stories','practical','playful'])]:
   f[k]=rng.choice(choices)
  mem.append({'member_id':'syn_'+format(i,'032x'),'pool_id':'stress','synthetic':True,'age':rng.randint(21,46),
              'gender':rng.choice(['man','woman','non_binary']),'zone':'zone_a','arrived_day':0,'available':True,
              'fields':f,'field_status':{k:'observed' for k in f},'field_observed_day':{k:0 for k in f},'source':'synthetic_questionnaire'})
 return {'schema_version':'1.0.0','synthetic':True,'day':10,'ask_budget_remaining':12,
         'members':mem,'introductions':[],'feedback':[],'ask_log':[]}

def dense_process():
 state=all_compatible_state()
 assert len(json.dumps(request(state)).encode())<1024*1024
 t=time.perf_counter();out,elapsed=invoke(CMD,request(state),'10' if False else 10)
 ids=[v for p in out['pairs'] for v in p]
 assert len(out['pairs'])==100,(len(out['pairs']), 'expected maximum disjoint pairs')
 assert len(ids)==len(set(ids)) and all(len(x)==2 for x in out['pairs'])
 return {'edges':19900,'pairs':len(out['pairs']),'wall_s':round(elapsed,3),'request_bytes':len(json.dumps(request(state)).encode())}

def sparse_process():
 state=all_compatible_state()
 for i,m in enumerate(state['members']):
  m['zone']='zone_'+str(i)
  m['fields']['acceptable_zones']=['zone_'+str(i)]
 out,elapsed=invoke(CMD,request(state))
 assert not out['pairs']
 return {'pairs':0,'wall_s':round(elapsed,3)}

def huge_memory():
 state={'schema_version':'1.0.0','synthetic':True,'day':0,'ask_budget_remaining':12,'members':[],'introductions':[],'feedback':[],'ask_log':[]}
 memory={'blob':'x'*900000}
 out,elapsed=invoke(CMD,request(state,'ask',memory))
 assert out['memory']==memory and out['asks']==[]
 return {'response_bytes':len(json.dumps(out).encode()),'wall_s':round(elapsed,3)}

def repeated_and_past():
 state=all_compatible_state(n=40)
 out1,_=invoke(CMD,request(state));out2,_=invoke(CMD,request(state))
 assert out1==out2
 state['introductions']=[{'user_a':x[0],'user_b':x[1],'assigned_day':0} for x in out1['pairs']]
 out3,_=invoke(CMD,request(state))
 assert not any(tuple(sorted(x)) in {tuple(sorted(y)) for y in out1['pairs']} for x in out3['pairs'])
 return {'initial_pairs':len(out1['pairs']),'after_past_pairs':len(out3['pairs'])}

def differential_eligibility():
 n=0;rng=random.Random(8001)
 for variant in ['development','sparse','cold_start','delayed','shift','drift']:
  sim=Simulator(generate(rng.randint(100000,999999),200,'stress',variant))
  mem=sim.observe()['members']
  for a,b in itertools.combinations(mem,2):
   n+=1
   expected=eligibility(a,b)['status'];actual=hard_status(a,b)
   if expected!=actual:raise AssertionError(f'eligibility mismatch: {expected} {actual}')
 return {'pairwise_checks':n,'mismatches':0}

def local_simulator_actions():
 n=0;asks=0;matches=0
 for variant in ['development','sparse','cold_start','delayed','shift','drift']:
  sim=Simulator(generate(2828,200,'stress',variant));memory=None
  for day in range(7):
   for phase in ['ask','match']:
    req=request(sim.observe(),phase,memory)
    out=validate_response(decide(req),phase)
    memory=out['memory']
    if phase=='ask':
     ask_list=out['asks'];cost=sum(3 if x['field']=='constraints' else 1 for x in ask_list)
     assert cost<=req['state']['ask_budget_remaining']
     sim.resolve_asks(ask_list);asks+=len(ask_list)
    else:
     sim.advance(out['pairs']);matches+=len(out['pairs'])
    n+=1
 return {'calls':n,'asks':asks,'matches':matches,'invalid':0}

def zero_near_budget():
 state=all_compatible_state(n=3)
 state['ask_budget_remaining']=0
 state['members'][0]['fields']['age_min']=None
 state['members'][0]['field_status']['age_min']='not_asked'
 out,_=invoke(CMD,request(state,'ask'))
 assert out['asks']==[]
 return {'asks':0}

if __name__=="__main__":
    for name,func in [
     ('unit_adversarial_randomized_eligibility',differential_eligibility),
     ('valid_policy_7day_six_scenarios',local_simulator_actions),
     ('dense_200_19900_edges_process',dense_process),
     ('sparse_200_process',sparse_process),
     ('max_memory_900k_process',huge_memory),
     ('repeat_and_determinism_process',repeated_and_past),
     ('zero_budget',zero_near_budget)]:check(name,func)
    print(json.dumps({'checks':len(LOG),'passed':sum(x['status']=='PASS' for x in LOG),'failed':sum(x['status']=='FAIL' for x in LOG)}))
