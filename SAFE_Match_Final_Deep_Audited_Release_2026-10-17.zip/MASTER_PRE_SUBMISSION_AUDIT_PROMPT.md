# MASTER PROMPT — SAFE-Match final pre-submission execution, audit, and repair

Act as a senior Python systems engineer, optimization researcher, adversarial tester, and release manager. You must work on the attached **SAFE-Match Round 2 project ZIP**, not generate a new mock solution. Today is 17 October 2026; the organizer's newer announcement gives the deadline as **23:59 IST today**. Prioritize a **legal, working, immutable submission** over speculative new algorithms.

**Absolute source hierarchy:** (1) organizer's currently released `PROBLEM_STATEMENT.md`, `docs/DATA_CONTRACT.md`, `docs/POLICY_INTERFACE.md`, `docs/SUBMISSION.md`, unmodified `kit.py`, `evaluate.py`, reference baselines and tests; (2) the provided executable project; (3) accompanying reports, which are untrusted until reproducible. The initial archive has `policy.py` SHA-256 `a0b772f99070c17170648d04852828aa3648d0115932e21a8f2e66cd68097b9a`. Recalculate this rather than assuming the archive is identical. Do not access hidden worlds, latent member values, future events, or private seeds.

## Phase 1: Freeze and inspect

1. Extract the ZIP into a clean working folder. Preserve an untouched original. List every file and its SHA-256. Run ZIP integrity checks. Verify the source and Docker build context are at the package root, with no missing import files or network-only runtime assets.
2. Diff the reference files against the organizer's actual released versions. Do not modify `kit.py` or `evaluate.py` to make tests pass. Flag any discrepancy and resolve against official public code.
3. Review the complete current `policy.py`, `requirements.txt`, Dockerfile and tests for subtle mistakes in reciprocal hard eligibility, consent from unknown/refused fields, availability, past introductions, duplicate actions, budget accounting, JSON schema, memory carried between fresh processes, stderr/stdout, deterministic tie behavior, solver/fallback behavior, memory limits and runtime.
4. Inspect documentation for actual training seeds (there is **no fitted model** in this policy), inference randomness (there is **no randomized inference**), public evaluation seeds, dependency licenses, experimental provenance, limitations and exact reproduction commands.

## Phase 2: Run tests — never invent results

Run commands and save their true stdout, stderr, return codes, timing, package versions and environment:

```bash
python -m unittest -v
python stress_process.py
python preflight.py
python evaluate.py --policy policy.py --seeds 711 --variants development --output results/final_711.json
python reproduce_public.py --seeds 101,102,103 --variants all --output results/final_public.json
```

Test ask/match as **separate, fresh Python processes**, using real legal input JSON. Require exactly one valid JSON object on stdout, exit code 0, exact permitted response keys, finite bounded memory, and zero extraneous stdout. Use organizer `evaluate.validate_response` and `kit.Simulator` to validate actions. Execute one complete 60-day + 40-day episode before claiming the code runs. Test empty and edge-case requests; 200-person dense and sparse states; near-1 MiB memory; hard conflicts, unknowns, refusals, past introductions, pending members, and the budget boundary. Compare local `hard_status` against official `kit.eligibility` on randomized members. Test the NetworkX-unavailable fallback using an environment that actually prevents its import. Record the resulting action hash.

## Phase 3: Mandatory Docker validation

Run on a machine with Docker and network access for **build time only**:

```bash
docker build --pull -t safe-match:submission .
python evaluate.py --image safe-match:submission --seeds 101 --variants development --output results/container_101.json
python preflight.py --require-docker
```

Verify the actual image contains only needed inference code/assets, builds without credentials, is runnable as UID 65534 under the organizer's exact offline sandbox constraints, stays under 10 seconds **per invocation** (including startup), 2 CPUs, 1 GiB RAM, 64 PIDs and 1 MiB input/output/memory. Record the **maximum per-call wall time** and peak memory, not only episode totals. Confirm the installed NetworkX version is exactly the version pinned in `requirements.txt` (3.4.2 in the original artifact). If Docker isn't installed, say `DOCKER BLOCKED — NOT SUBMISSION CERTIFIED`; never substitute subprocess or mocked Docker output for actual validation.

The official `python verify_data.py` command requires the separate organizer public data, manifest and checksum files. If verifying that data, clone the official starter, generate/retrieve the public data and execute the **unmodified official** verifier. Never replace it with a superficial look-alike script or quietly label an omitted check as PASS.

## Phase 4: Repair only verified defects

For every issue, create an issue register with: severity, precise file/line, observed failure, minimum reproduction command and input, root cause, smallest safe patch, and evidence of resolution. Fix blockers and real correctness violations before any scoring experiments. For each patch, rerun the focused test, all unit tests, adversarial checks and at least one full official evaluator episode. Compare action hashes and metrics against the unchanged baseline to catch regressions. Changes should be isolated, reversible and documented. Never improve unit-test counts by weakening assertions or changing the evaluator. If a proposed optimization reduces holdout MSMI, introduces an illegal action, slows worst-case inference beyond the limit or can't be validated, **revert it**. Report a known weakness rather than introducing a new guess under deadline pressure.

## Phase 5: Report genuine benchmark evidence

On paired public seeds across **all six official scenario families**, evaluate SAFE-Match, greedy, no-asks and random-feasible using the organizer's public `kit.py`; separately distinguish in-process experiments from real fresh-process `evaluate.py` and assessed Docker evaluation. Preserve episode-level results, raw qualifying MSMI counts/denominators, family-balanced MSMI per 100 arrived, coverage, first wait, unserved members, missing feedback, clarification units, invalid episodes, per-call runtime and input/output traces. Use seed-blocked inference; related scenario families on the same seed are not independent. A small public advantage is not proof of private ranking. Do not infer hidden outcomes or leak future/true preference fields into policy decisions.

## Phase 6: Release gate and deliverables

Deliver one clean root-level submission folder with `policy.py`, `Dockerfile`, `requirements.txt`, README, report, tests, machine-readable full-episode results, provenance/licenses and reproducible scripts. Keep organizer data OUT of the Docker image; keep only needed inference dependencies in the image. Provide a full diff, original and final SHA-256 values, all test logs, exact commands and code revisions. Verify archive integrity and show its SHA-256. Explain how to publish a public immutable GitHub commit with its **40-character SHA** or a version-specific immutable archive with its SHA-256, and how to link the source, report and results in the organizer's Final submission issue. Never claim the issue was submitted unless you actually submitted it and obtained confirmation. The newest organizer announcement (17 October 2026 23:59 IST) supersedes the stale public GitHub guide (18 October).

End with a concise evidence-based table using only `PASS`, `FAIL`, or `BLOCKED` for: archive, imports, unit tests, exact eligibility, legal actions, full official evaluator, 200-member adversarial calls, pinned dependency, Docker image, Docker evaluator, complete results, immutable public artifact, and actual issue submission. Classify **READY** only after the Docker and immutable release gates pass; otherwise **CONDITIONALLY READY** or **NOT READY** with specific next actions. No invented logs, scores, confidence claims, or code executions.
