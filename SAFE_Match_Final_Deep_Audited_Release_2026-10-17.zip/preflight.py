"""SAFE-Match local release gate. Runs real subprocess checks; Docker is mandatory for a final PASS.
Usage: python preflight.py [--require-docker]
This script does not use or imitate private organizer evaluation.
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED_BLOBS = {
    'kit.py': 'b0356b84211debdb8fc1c3ea81348a034dd2ddbd',
    'evaluate.py': 'f9fa2617a3ef84da85502ec2bd730185d5049f65',
    'baseline/official_reference_policy.py': '39766a8ea8c1d5090093e1a93c556f9d47ef8b29',
}

def git_blob_hash(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def launch(args, stdin=None, timeout=120, env=None):
    return subprocess.run(args, input=stdin, text=True, capture_output=True, timeout=timeout, cwd=ROOT, env=env)

def check(name, cond, detail='', checks=None):
    checks.append({'name':name, 'status':'PASS' if cond else 'FAIL', 'detail':detail})

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--require-docker',action='store_true',help='Nonzero exit unless actual Docker image build and evaluator pass')
    p.add_argument('--docker-seed',default='101',help='Public development seed for Docker evaluator')
    p.add_argument('--output',default='results/preflight_2026-10-17.json')
    args=p.parse_args()
    checks=[]
    required=['policy.py','Dockerfile','requirements.txt','README.md','REPORT.md','evaluate.py','kit.py']
    check('files_at_root',all((ROOT/name).is_file() for name in required),', '.join(name for name in required if not (ROOT/name).is_file()),checks)
    for name,expected in EXPECTED_BLOBS.items():
        data=(ROOT/name).read_bytes()
        check('official_git_blob_'+name,git_blob_hash(data)==expected,git_blob_hash(data),checks)
    # The assessment image imports only the bundled pure-Python dependency;
    # verify it works without site-packages or a package index.
    env=os.environ.copy()
    env['PYTHONPATH']=str(ROOT/'vendor')
    env['PYTHONDONTWRITEBYTECODE']='1'
    offline=launch([sys.executable,'-S','-c',
                    "import networkx; print(networkx.__version__, networkx.__file__)"],
                   timeout=10,env=env)
    check('offline_vendored_networkx',
          offline.returncode==0 and offline.stdout.startswith('3.6.1 ')
          and str(ROOT/'vendor') in offline.stdout,
          offline.stdout.strip()+offline.stderr[-250:],checks)
    vendor_check=launch([sys.executable,'-S','verify_vendor.py'],timeout=25)
    check('vendored_dependency_integrity',vendor_check.returncode==0,
          vendor_check.stdout.strip()+vendor_check.stderr[-350:],checks)
    dockerfile=(ROOT/'Dockerfile').read_text()
    check('docker_build_requires_no_package_download',
          'COPY vendor/' in dockerfile and 'pip install' not in dockerfile
          and 'ENTRYPOINT ["python", "-S", "/app/policy.py"]' in dockerfile,
          'No pip download; bundled exact matcher used with site disabled',checks)
    test=launch([sys.executable,'-S','-m','unittest','-v'],timeout=120,env=env)
    check('unittest',test.returncode==0, '\n'.join(test.stderr.splitlines()[-6:]),checks)
    from evaluate import validate_response, strict_json
    state={'schema_version':'1.0.0','synthetic':True,'day':0,'ask_budget_remaining':12,
           'members':[],'introductions':[],'feedback':[],'ask_log':[]}
    for phase in ('ask','match'):
        req={'schema_version':'1.0.0','phase':phase,'state':state,'memory':{'marker':'same'}}
        run=launch([sys.executable,'-S',str(ROOT/'policy.py')], json.dumps(req),timeout=10,env=env)
        try:
            response=validate_response(strict_json(run.stdout.strip()),phase)
            valid=run.returncode==0 and response['memory']==req['memory'] and not run.stderr and len(run.stdout.splitlines())==1
        except Exception:
            valid=False
        check('fresh_process_'+phase,valid,'exit='+str(run.returncode)+', stderr='+run.stderr[:300],checks)
    if shutil.which('docker'):
        build=launch(['docker','build','-t','safe-match:preflight','.'],timeout=300)
        check('docker_build',build.returncode==0,build.stderr[-500:],checks)
        if build.returncode==0:
            evaluation=launch([sys.executable,'evaluate.py','--image','safe-match:preflight',
                                '--seeds',args.docker_seed,'--variants','development',
                                '--output','results/preflight_docker_'+args.docker_seed+'.json'],timeout=500)
            check('docker_official_evaluator',evaluation.returncode==0,evaluation.stdout[-500:]+evaluation.stderr[-500:],checks)
    else:
        checks.append({'name':'docker_build_and_evaluator','status':'BLOCKED',
                       'detail':'Docker executable not available; must run on a machine with Docker before submission'})
    result={'source_sha256':hashlib.sha256((ROOT/'policy.py').read_bytes()).hexdigest(),
            'python':sys.version.split()[0],'checks':checks,
            'code_checks_passed':all(c['status']=='PASS' for c in checks if c['status']!='BLOCKED'),
            'docker_verified':any(c['name']=='docker_official_evaluator' and c['status']=='PASS' for c in checks)}
    path=ROOT / args.output
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0 if all(c['status']=='PASS' for c in checks) else (2 if args.require_docker or any(c['status']=='FAIL' for c in checks) else 0)

if __name__=='__main__':
    raise SystemExit(main())
